<script setup lang="ts">

</script>

<template>
  <div>
    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Cumque, voluptas.
  </div>
</template>

<style scoped>

</style>