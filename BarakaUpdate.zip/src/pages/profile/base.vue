<script setup lang="ts">

import Header from "../../components/profile/header.vue";
</script>

<template>
   <div class="bg-bgGray h-full">
     <Header/>
     <RouterView/>
   </div>
</template>

<style scoped>

</style>