<script setup lang="ts">

</script>

<template>
  <h2 class="text-to text-3xl font-obold">
    <slot/>
  </h2>
</template>

<style scoped>

</style>