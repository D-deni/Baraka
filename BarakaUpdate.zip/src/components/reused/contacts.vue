<script setup lang="ts">
import ImgContact from '/img/elements/vectors/contact.webp?url'
import VectorEllipse from '/public/img/elements/vectors/ellipses-two.svg?skipsvgo'
import ArrowLeft from '/img/elements/vectors/arrow-left.webp?url'
import ImgMail from "/img/elements/vectors/mail.webp?url"
import TheTitle from "../UI/TheTitle.vue";

defineProps({
  botBlockFlag: Boolean,
  contactBlockFlag: Boolean,
  aboutBlockFlag: Boolean,
  vacanciesBlockFlag: Boolean,
  titleFlag: Boolean,
  titleStyle: String,
  blockStyle: String,
  imgVector: String,
  isEmail: String
})
</script>

<template>
  <div class="max-sm:px-6">
    <div class="bg-[#F7F6F9] w-full flex flex-col gap-y-14 max-md:gap-y-6 justify-center relative  max-lg:h-max max-sm:h-max rounded-3xl p-10 max-sm:!p-4 mt-48 max-sm:my-20" :class="blockStyle">
      <TheTitle v-if="titleFlag">{{$t('Контакты')}}</TheTitle>
      <div v-if="vacanciesBlockFlag" class="flex flex-col gap-y-4 gap-x-6">
        <div class="flex flex-col gap-y-4 gap-x-6 z-10 max-md:!items-center">
          <TheTitle class="!z-10 w-full max-md:text-xl max-md:!text-center" :class="titleStyle"><slot name="title"/></TheTitle>
          <div class="flex items-center gap-x-4 z-10 mt-[40px]">
            <div class="flex items-center gap-x-4">
              <div>
                <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M15.583 18.7943H6.41634C3.66634 18.7943 1.83301 17.4193 1.83301 14.2109V7.79427C1.83301 4.58594 3.66634 3.21094 6.41634 3.21094H15.583C18.333 3.21094 20.1663 4.58594 20.1663 7.79427V14.2109C20.1663 17.4193 18.333 18.7943 15.583 18.7943Z" stroke="#FE5000" stroke-width="1.375" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M15.5833 8.25L12.7142 10.5417C11.77 11.2933 10.2208 11.2933 9.27665 10.5417L6.41666 8.25" stroke="#FE5000" stroke-width="1.375" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </div>
              <a href="mailto:marketing@barakamarket.uz"><span>{{$t('Email')}}:</span> {{isEmail}}</a>
            </div>
            <div class="max-md:hidden">
              <img class="w-9/12" :src="ArrowLeft" alt="">
            </div>
          </div>
        </div>
        <div v-if="$route.path === '/providers' || $route.path === '/advertisers'" class="">
          <img :src="ImgMail" alt="" class="absolute max-lg:static top-10 w-max right-60 max-md:w-max mx-auto"/>
          <VectorEllipse class="absolute right-0 top-0 h-full"/>
        </div>
      </div>
      <div v-if="aboutBlockFlag" class="flex flex-col gap-y-6 relative ">
        <div class="flex gap-x-2 items-center">
          <div>
            <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M11 12.3118C12.5795 12.3118 13.86 11.0313 13.86 9.4518C13.86 7.87226 12.5795 6.5918 11 6.5918C9.42048 6.5918 8.14001 7.87226 8.14001 9.4518C8.14001 11.0313 9.42048 12.3118 11 12.3118Z" stroke="#FE5000" stroke-width="1.375"/>
              <path d="M3.31823 7.78315C5.12406 -0.15518 16.8849 -0.146013 18.6816 7.79232C19.7357 12.449 16.8391 16.3907 14.2999 18.829C12.4574 20.6073 9.5424 20.6073 7.69073 18.829C5.16073 16.3907 2.26406 12.4398 3.31823 7.78315Z" stroke="#FE5000" stroke-width="1.375"/>
            </svg>
          </div>
          <p class="flex gap-x-2 text-[17px] font-oregular max-sm:flex-col">{{$t('Адрес')}}:<span>{{$t('Республика Узбекистан г.Ташкент, Яккасарайский район, ул.Бабура 74.')}}</span></p>
        </div>
        <a href="mailto:info@barakamarket.uz" class="flex gap-x-2 items-center">
          <div>
            <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M15.583 18.7923H6.41634C3.66634 18.7923 1.83301 17.4173 1.83301 14.209V7.79232C1.83301 4.58398 3.66634 3.20898 6.41634 3.20898H15.583C18.333 3.20898 20.1663 4.58398 20.1663 7.79232V14.209C20.1663 17.4173 18.333 18.7923 15.583 18.7923Z" stroke="#FE5000" stroke-width="1.375" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M15.5833 8.25L12.7142 10.5417C11.77 11.2933 10.2208 11.2933 9.27665 10.5417L6.41666 8.25" stroke="#FE5000" stroke-width="1.375" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
          </div>
          <p class="flex gap-x-2 text-[17px] font-oregular max-sm:flex-col">{{$t('Email:')}}<span>{{$t('info@barakamarket.uz')}}</span></p>
        </a>
      </div>
      <div v-if="botBlockFlag" class="flex gap-x-10 max-lg:flex-col max-lg:gap-y-6 max-lg:justify-center">
        <div class="pr-6 border-r max-lg:border-none flex flex-col max-sm:flex-row max-sm:mx-auto max-sm:gap-x-10 max-[528px]:flex-col gap-y-4 text-[17px]">
         <a href="https://t.me/HR_URBAN" target="_blank" class="flex gap-x-2 items-center">
           <div>
             <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
               <rect width="40" height="40" rx="20" fill="#FE5000" fill-opacity="0.06"/>
               <path d="M11.3796 18.9396C13.1983 17.9568 15.2284 17.1365 17.1254 16.3121C20.3888 14.9617 23.6651 13.6347 26.9746 12.3993C27.6185 12.1888 28.7754 11.9829 28.8888 12.919C28.8267 14.2441 28.5712 15.5615 28.3959 16.8788C27.951 19.7757 27.4368 22.6627 26.9354 25.5501C26.7626 26.5119 25.5345 27.0097 24.7487 26.3943C22.8603 25.1428 20.9573 23.9036 19.0929 22.6232C18.4822 22.0143 19.0485 21.1401 19.5939 20.7054C21.1493 19.2016 22.7989 17.9239 24.273 16.3424C24.6706 15.4004 23.4957 16.1943 23.1082 16.4376C20.9789 17.8771 18.9016 19.4046 16.6566 20.6697C15.5099 21.289 14.1733 20.7598 13.0271 20.4142C11.9993 19.9968 10.4933 19.5762 11.3795 18.9397L11.3796 18.9396Z" fill="#FE5000"/>
             </svg>
           </div>
           <p>{{'@HR_URBAN'}}</p>
         </a>
         <a href="tel:+998908301940" class="flex gap-x-2 items-center font-omedium">
           <div>
             <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
               <rect width="40" height="40" rx="20" fill="#FE5000" fill-opacity="0.06"/>
               <path d="M29.1392 25.8032C29.1392 26.1332 29.0658 26.4723 28.91 26.8023C28.7542 27.1323 28.5525 27.444 28.2867 27.7373C27.8375 28.2323 27.3425 28.5898 26.7833 28.819C26.2333 29.0482 25.6375 29.1673 24.9958 29.1673C24.0608 29.1673 23.0617 28.9473 22.0075 28.4982C20.9533 28.049 19.8992 27.444 18.8542 26.6832C17.8 25.9132 16.8008 25.0607 15.8475 24.1165C14.9033 23.1632 14.0508 22.164 13.29 21.119C12.5383 20.074 11.9333 19.029 11.4933 17.9932C11.0533 16.9482 10.8333 15.949 10.8333 14.9957C10.8333 14.3723 10.9433 13.7765 11.1633 13.2265C11.3833 12.6673 11.7317 12.154 12.2175 11.6957C12.8042 11.1182 13.4458 10.834 14.1242 10.834C14.3808 10.834 14.6375 10.889 14.8667 10.999C15.105 11.109 15.3158 11.274 15.4808 11.5123L17.6075 14.5098C17.7725 14.739 17.8917 14.9498 17.9742 15.1515C18.0567 15.344 18.1025 15.5365 18.1025 15.7107C18.1025 15.9307 18.0383 16.1507 17.91 16.3615C17.7908 16.5723 17.6167 16.7923 17.3967 17.0123L16.7 17.7365C16.5992 17.8373 16.5533 17.9565 16.5533 18.1032C16.5533 18.1765 16.5625 18.2407 16.5808 18.314C16.6083 18.3873 16.6358 18.4423 16.6542 18.4973C16.8192 18.7998 17.1033 19.194 17.5067 19.6707C17.9192 20.1473 18.3592 20.6332 18.8358 21.119C19.3308 21.6048 19.8075 22.054 20.2933 22.4665C20.77 22.8698 21.1642 23.1448 21.4758 23.3098C21.5217 23.3282 21.5767 23.3557 21.6408 23.3832C21.7142 23.4107 21.7875 23.4198 21.87 23.4198C22.0258 23.4198 22.145 23.3648 22.2458 23.264L22.9425 22.5765C23.1717 22.3473 23.3917 22.1732 23.6025 22.0632C23.8133 21.9348 24.0242 21.8707 24.2533 21.8707C24.4275 21.8707 24.6108 21.9073 24.8125 21.9898C25.0142 22.0723 25.225 22.1915 25.4542 22.3473L28.4883 24.5015C28.7267 24.6665 28.8917 24.859 28.9925 25.0881C29.0842 25.3173 29.1392 25.5465 29.1392 25.8032Z" stroke="#FE5000" stroke-width="1.375" stroke-miterlimit="10"/>
               <path d="M25.9584 17.2513C25.9584 16.7013 25.5275 15.858 24.8859 15.1705C24.2992 14.538 23.52 14.043 22.75 14.043" stroke="#FE5000" stroke-width="1.375" stroke-linecap="round" stroke-linejoin="round"/>
               <path d="M29.1667 17.2507C29.1667 13.7032 26.2975 10.834 22.75 10.834" stroke="#FE5000" stroke-width="1.375" stroke-linecap="round" stroke-linejoin="round"/>
             </svg>
           </div>
           <p >{{'+998 90 830 19 40'}}</p>
         </a>
        </div>
        <div class="flex flex-col gap-y-2 font-oregular">
          <p class="w-8/12 text-[17px] max-lg:w-7/12 max-sm:w-full max-sm:text-center">{{$t('Более 100 вакансий рядом с твоим домом ждут тебя в нашем 👇')}}</p>
          <div class="flex items-center gap-x-2 bg-white w-max px-4 py-2 rounded-lg underline max-sm:text-center max-sm:mx-auto">
            <a class="text-[22px] text-to " href="https://t.me/Baraka_Jbot" target="_blank">{{$t('боте')}}</a>
            <div>
              <svg width="22" height="22" viewBox="0 0 22 22" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M13 17L19 11.5L13 6" stroke="#FE5000" stroke-width="1.375" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
                <path d="M4 11L19 11" stroke="#FE5000" stroke-width="1.375" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div v-if="contactBlockFlag">
        <div class="flex items-end gap-x-10">
          <div class="bg-white shadow-blockShadow flex flex-col gap-y-10 p-8 rounded-2xl">
            <p class="text-[17px] font-oregular">{{$t('Обращайтесь к нам в колл-центр по телефону:')}}</p>
            <div class="flex items-center gap-x-4 ">
              <div>
                <svg width="40" height="40" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M36.6167 30.5526C36.6167 31.1526 36.4833 31.7693 36.2 32.3693C35.9167 32.9693 35.55 33.5359 35.0667 34.0693C34.25 34.9693 33.35 35.6193 32.3333 36.0359C31.3333 36.4526 30.25 36.6693 29.0833 36.6693C27.3833 36.6693 25.5667 36.2693 23.65 35.4526C21.7333 34.6359 19.8167 33.5359 17.9167 32.1526C16 30.7526 14.1833 29.2026 12.45 27.4859C10.7333 25.7526 9.18334 23.9359 7.80001 22.0359C6.43334 20.1359 5.33334 18.2359 4.53334 16.3526C3.73334 14.4526 3.33334 12.6359 3.33334 10.9026C3.33334 9.76927 3.53334 8.68594 3.93334 7.68594C4.33334 6.66927 4.96668 5.73594 5.85001 4.9026C6.91668 3.8526 8.08334 3.33594 9.31668 3.33594C9.78334 3.33594 10.25 3.43594 10.6667 3.63594C11.1 3.83594 11.4833 4.13594 11.7833 4.56927L15.65 10.0193C15.95 10.4359 16.1667 10.8193 16.3167 11.1859C16.4667 11.5359 16.55 11.8859 16.55 12.2026C16.55 12.6026 16.4333 13.0026 16.2 13.3859C15.9833 13.7693 15.6667 14.1693 15.2667 14.5693L14 15.8859C13.8167 16.0693 13.7333 16.2859 13.7333 16.5526C13.7333 16.6859 13.75 16.8026 13.7833 16.9359C13.8333 17.0693 13.8833 17.1693 13.9167 17.2693C14.2167 17.8193 14.7333 18.5359 15.4667 19.4026C16.2167 20.2693 17.0167 21.1526 17.8833 22.0359C18.7833 22.9193 19.65 23.7359 20.5333 24.4859C21.4 25.2193 22.1167 25.7193 22.6833 26.0193C22.7667 26.0526 22.8667 26.1026 22.9833 26.1526C23.1167 26.2026 23.25 26.2193 23.4 26.2193C23.6833 26.2193 23.9 26.1193 24.0833 25.9359L25.35 24.6859C25.7667 24.2693 26.1667 23.9526 26.55 23.7526C26.9333 23.5193 27.3167 23.4026 27.7333 23.4026C28.05 23.4026 28.3833 23.4693 28.75 23.6193C29.1167 23.7693 29.5 23.9859 29.9167 24.2693L35.4333 28.1859C35.8667 28.4859 36.1667 28.8359 36.35 29.2526C36.5167 29.6693 36.6167 30.0859 36.6167 30.5526Z" stroke="#FE5000" stroke-width="2.5" stroke-miterlimit="10"/>
                  <path d="M30.8333 15.0072C30.8333 14.0072 30.05 12.4738 28.8833 11.2238C27.8167 10.0738 26.4 9.17383 25 9.17383" stroke="#FE5000" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                  <path d="M36.6667 15.0026C36.6667 8.55261 31.45 3.33594 25 3.33594" stroke="#FE5000" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </div>
              <p class="text-[50px] text-to font-obold">1247</p>
            </div>
          </div>
          <div class="absolute right-0 left-0 top-0 bottom-0 flex items-center justify-center w-full max-sm:hidden">
            <img :src="ArrowLeft" alt="">
          </div>
        </div>
      </div>
      <img v-if="$route.path !== '/providers' && $route.path !== '/advertisers'" :class="imgVector" class="absolute -top-[90px] max-lg:hidden max-xl:w-4/12 max-xl:-top-10 max-md:-top-20 max-md:w-8/12 max-lg:w-6/12 right-0" :src="ImgContact" alt="">
    </div>
  </div>
</template>

<style scoped>

</style>