import uz from './uz.json';
import ru from './ru.json'


export const defaultLocale = 'RU'

export const languages  = {uz, ru}