
export const globalUrl = 'https://backend.barakamarket.uz/'



