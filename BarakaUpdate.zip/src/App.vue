<script setup lang="ts">

import {onMounted} from "vue";

onMounted(() => {

})
</script>

<template>
  <RouterView/>
</template>

<style scoped>

</style>
